package com.rafistra.kedaireka.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rafistra.kedaireka.Adapter.HistoryAdapter;
import com.rafistra.kedaireka.Model.AllData;
import com.rafistra.kedaireka.Model.DashboardLatestSensorData;
import com.rafistra.kedaireka.Model.HistoryModel;
import com.rafistra.kedaireka.R;
import com.rafistra.kedaireka.RestApi.APIService;
import com.rafistra.kedaireka.RestApi.ApiClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class History extends Fragment {
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    TextView coba;
    String[] list_lantai = {"Lantai 1", "Lantai 2", "Lantai 3"};

    AutoCompleteTextView autoCompleteText;
    ArrayAdapter<String> adapterItems;

    Integer nodeId, node, lantai;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        // Inflate the layout for this fragment
        recyclerView= (RecyclerView) view.findViewById(R.id.card_recycle_view);
        coba = (TextView) view.findViewById(R.id.nodeid_history);


        //LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);

        //AutoComplete Dropdown
        autoCompleteText = view.findViewById(R.id.auto_complete_txt);
        adapterItems = new ArrayAdapter<String>(getActivity(), R.layout.list_lantai, list_lantai);
        autoCompleteText.setAdapter(adapterItems);

        //sharedpreferences get nodeId
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("KANDANG", Context.MODE_PRIVATE);
        String nodeId_str = sharedPreferences.getString("nodeId","");
        nodeId = Integer.parseInt(nodeId_str);
        coba.setText(String.valueOf(nodeId));

        autoCompleteText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                String item = parent.getItemAtPosition(position).toString();
                switch (position){
                    case 0:
                        lantai = 1;
                        loadDataHistory();
                        break;
                    case 1:
                        lantai = 2;
                        loadDataHistory();
                        break;
                    case 2:
                        lantai = 3;
                        loadDataHistory();
                        break;
                }

                Toast.makeText(getContext(), "Memilih "+item,Toast.LENGTH_SHORT).show();
            }
        });

//        loadDataHistory();

        return view;
    }

    private void loadDataHistory() {
        APIService service = ApiClient.getClient().create(APIService.class);
        service.getHistory(nodeId,lantai).enqueue(new Callback<HistoryModel>() {
            @Override
            public void onResponse(Call<HistoryModel> call, Response<HistoryModel> response) {
                if(response.isSuccessful()){
                    List<AllData> dataList = response.body().getAllData();
                    for(int i=0; i<dataList.size(); i++){
                        adapter = new HistoryAdapter((ArrayList<AllData>)dataList);
                        recyclerView.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                    }
                }
            }
            @Override
            public void onFailure(Call<HistoryModel> call, Throwable t) {

            }
        });
    }


}