package com.rafistra.kedaireka.Model;

public class DashboardLatestSensorData {
    String ammonia_sensor;
    String humidity_sensor;
    String temperature_sensor;

    public DashboardLatestSensorData() {
    }

    public DashboardLatestSensorData(String ammonia_sensor, String humidity_sensor, String temperature_sensor) {
        this.ammonia_sensor = ammonia_sensor;
        this.humidity_sensor = humidity_sensor;
        this.temperature_sensor = temperature_sensor;
    }

    public String getAmmonia_sensor() {
        return ammonia_sensor;
    }

    public String getHumidity_sensor() {
        return humidity_sensor;
    }

    public String getTemperature_sensor() {
        return temperature_sensor;
    }

}
