package com.rafistra.kedaireka.RestApi;

import com.rafistra.kedaireka.Model.Dashboard.DashboardStatusActuator;
import com.rafistra.kedaireka.Model.Dashboard.DashboardStatusData;
import com.rafistra.kedaireka.Model.Dashboard.DashboardStatusModel;
import com.rafistra.kedaireka.Model.HistoryModel;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface APIService {



    String main_url = "/api/data/all/";
    String nodeId = "1";
    String lantai = "/2";

    String url = main_url+nodeId+lantai;


    // GET TOKEN API SERVICE
    // region TokenActivityMethods
    @FormUrlEncoded
    @POST("/api/login")
        @Headers({
                "Content-Type: application/x-www-form-urlencoded",
        })
    Call<ResponseBody> getToken(@Field("email") String email,
                                @Field("password") String password);

    String uri = "/api/data/actuator/1/1";
    //APi masih bersifat Statis jadi harus satu-satu
    @GET(uri)
    Call<DashboardStatusModel> getStatusData();

    @GET("/api/data/actuator/1/2")
    Call<DashboardStatusModel> getStatusData2();

    @GET("/api/data/actuator/all")
    Call<DashboardStatusModel> getStatus(@Query("nodeId")Integer nodeId);

    @GET("/api/data/actuator/1/1")
    Call<DashboardStatusActuator> getStatusActuator();

    @GET("/api/data/all")
    Call<HistoryModel> getHistory(
            @Query("nodeId") Integer nodeId,
            @Query("lantai") Integer lantai);




}



