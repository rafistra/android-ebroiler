package com.rafistra.kedaireka.Fragment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.rafistra.kedaireka.Activity.DataRecordActivity;
import com.rafistra.kedaireka.Model.Dashboard.DashboardStatusData;
import com.rafistra.kedaireka.Model.Dashboard.DashboardStatusModel;
import com.rafistra.kedaireka.R;
import com.rafistra.kedaireka.RestApi.APIService;
import com.rafistra.kedaireka.RestApi.ApiClient;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Dashboard extends Fragment {

    TextView date_time, temperature, humidity, ammonia;
    TextView user_owner;
    TextView txt_fan1, txt_fan2, txt_fan3, txt_fan4, txt_fan5, txt_fan6, txt_fan7, txt_fan8, txt_heater1, txt_heater2, txt_evaporator;
    ImageView dash_on_fan1, dash_off_fan1, dash_on_fan2, dash_off_fan2, dash_on_fan3, dash_off_fan3, dash_on_fan4, dash_off_fan4, dash_on_fan5, dash_off_fan5, dash_on_fan6, dash_off_fan6, dash_on_fan7, dash_off_fan7, dash_on_fan8, dash_off_fan8, dash_on_heater1, dash_off_heater1, dash_on_heater2, dash_off_heater2, dash_on_evaporator, dash_off_evaporator;
    ImageView more_data_record;
    String[] list_lantai = {"Lantai 1", "Lantai 2", "Lantai 3"};

    AutoCompleteTextView autoCompleteText;

    ArrayAdapter<String> adapterItems;

    DashboardStatusModel status;

    Integer node;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        date_time   = view.findViewById(R.id.date_time);
        temperature = view.findViewById(R.id.dash_temperature);
        humidity    = view.findViewById(R.id.dash_humidity);
        ammonia     = view.findViewById(R.id.dash_ammonia);
        user_owner  = view.findViewById(R.id.name_owner);

        dash_on_fan1 = view.findViewById(R.id.dash_on_fan1);
        dash_on_fan2 = view.findViewById(R.id.dash_on_fan2);
        dash_on_fan3 = view.findViewById(R.id.dash_on_fan3);
        dash_on_fan4 = view.findViewById(R.id.dash_on_fan4);
        dash_on_fan5 = view.findViewById(R.id.dash_on_fan5);
        dash_on_fan6 = view.findViewById(R.id.dash_on_fan6);
        dash_on_fan7 = view.findViewById(R.id.dash_on_fan7);
        dash_on_fan8 = view.findViewById(R.id.dash_on_fan8);
        dash_on_heater1 = view.findViewById(R.id.dash_on_heater1);
        dash_on_heater2 = view.findViewById(R.id.dash_on_heater2);
        dash_on_evaporator = view.findViewById(R.id.dash_on_evaporator);
        dash_off_fan1 = view.findViewById(R.id.dash_off_fan1);
        dash_off_fan2 = view.findViewById(R.id.dash_off_fan2);
        dash_off_fan3 = view.findViewById(R.id.dash_off_fan3);
        dash_off_fan4 = view.findViewById(R.id.dash_off_fan4);
        dash_off_fan5 = view.findViewById(R.id.dash_off_fan5);
        dash_off_fan6 = view.findViewById(R.id.dash_off_fan6);
        dash_off_fan7 = view.findViewById(R.id.dash_off_fan7);
        dash_off_fan8 = view.findViewById(R.id.dash_off_fan8);
        dash_off_heater1 = view.findViewById(R.id.dash_off_heater1);
        dash_off_heater2 = view.findViewById(R.id.dash_off_heater2);
        dash_off_evaporator = view.findViewById(R.id.dash_off_evaporator);

        txt_fan1      = view.findViewById(R.id.status_fan);
        txt_fan2      = view.findViewById(R.id.status_fan2);
        txt_fan3      = view.findViewById(R.id.status_fan3);
        txt_fan4      = view.findViewById(R.id.status_fan4);
        txt_fan5      = view.findViewById(R.id.status_fan5);
        txt_fan6      = view.findViewById(R.id.status_fan6);
        txt_fan7      = view.findViewById(R.id.status_fan7);
        txt_fan8      = view.findViewById(R.id.status_fan8);
        txt_heater1   = view.findViewById(R.id.status_heater1);
        txt_heater2   = view.findViewById(R.id.status_heater2);
        txt_evaporator= view.findViewById(R.id.status_evaporator);

        //Misc
        more_data_record = view.findViewById(R.id.more_data_record);

        //Calendar
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        date_time.setText(currentDate);

        //SHAREDPREFERENCES
        //get name
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("NAME", Context.MODE_PRIVATE);
        String name_owner = sharedPreferences.getString("name","");
        user_owner.setText("Pak "+name_owner);

        //sharedpreferences get nodeId
        SharedPreferences sharedNodeId = getActivity().getSharedPreferences("KANDANG", Context.MODE_PRIVATE);
        String nodeId_str = sharedNodeId.getString("nodeId","");
        node = Integer.parseInt(nodeId_str);

        //AutoComplete Dropdown
        autoCompleteText = view.findViewById(R.id.auto_complete_txt);
        adapterItems = new ArrayAdapter<String>(getActivity(), R.layout.list_lantai, list_lantai);
        autoCompleteText.setAdapter(adapterItems);

        autoCompleteText.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                String item = parent.getItemAtPosition(position).toString();
                switch (position){
                    default:
                    case 0:
                        loadStatusData();
                        break;
                    case 1:
                        loadStatusData2();
                        break;
                    case 2:
                        loadStatusData();
                        break;
                }
                Toast.makeText(getContext(), "Memilih "+item,Toast.LENGTH_SHORT).show();
            }
        });

        more_data_record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), DataRecordActivity.class);
                startActivity(intent);
            }
        });
        //loadStatusData();
        // Inflate the layout for this fragment
        return view;
    }

    private void loadStatusData() {
        APIService service = ApiClient.getClient().create(APIService.class);
        service.getStatusData().enqueue(new Callback<DashboardStatusModel>() {
            @Override
            public void onResponse(Call<DashboardStatusModel> call, Response<DashboardStatusModel> response) {
                if(response.isSuccessful()){
                    status = response.body();
                    loadStatusActuator();
                }
            }
            @Override
            public void onFailure(Call<DashboardStatusModel> call, Throwable t) {
            }
        });
    }

    private void loadStatusData2() {
        APIService service = ApiClient.getClient().create(APIService.class);
        service.getStatusData2().enqueue(new Callback<DashboardStatusModel>() {
            @Override
            public void onResponse(Call<DashboardStatusModel> call, Response<DashboardStatusModel> response) {
                if(response.isSuccessful()){
                    status = response.body();
                    loadStatusActuator();
                }
            }
            @Override
            public void onFailure(Call<DashboardStatusModel> call, Throwable t) {
            }
        });
    }

    private void loadStatusActuator(){

        List<DashboardStatusData> statusList = status.getStatusData();
        Integer exhaust1, exhaust2, exhaust3, exhaust4, exhaust5, exhaust6, exhaust7, exhaust8, heater1, heater2, evaporator, nodeId;
        for(int i=0; i<statusList.size();i++){
            nodeId   = statusList.get(i).getNodeId();
            exhaust1 = statusList.get(i).getExhaust1();
            exhaust2 = statusList.get(i).getExhaust2();
            exhaust3 = statusList.get(i).getExhaust3();
            exhaust4 = statusList.get(i).getExhaust4();
            exhaust5 = statusList.get(i).getExhaust5();
            exhaust6 = statusList.get(i).getExhaust6();
            exhaust7 = statusList.get(i).getExhaust7();
            exhaust8 = statusList.get(i).getExhaust8();
            heater1  = statusList.get(i).getHeater1();
            heater2  = statusList.get(i).getHeater2();
            evaporator = statusList.get(i).getEvaporative();

            //Kipas 1
            if(exhaust1==1){
                txt_fan1.setText("ON");
                txt_fan1.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan1.setVisibility(View.VISIBLE);
                dash_off_fan1.setVisibility(View.GONE);
            } else {
                txt_fan1.setText("OFF");
                txt_fan1.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan1.setVisibility(View.GONE);
                dash_off_fan1.setVisibility(View.VISIBLE);
            }

            //Kipas 2
            if(exhaust2==1){
                txt_fan2.setText("ON");
                txt_fan2.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan2.setVisibility(View.VISIBLE);
                dash_off_fan2.setVisibility(View.GONE);
            } else {
                txt_fan2.setText("OFF");
                txt_fan2.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan2.setVisibility(View.GONE);
                dash_off_fan2.setVisibility(View.VISIBLE);
            }

            //Kipas 3
            if(exhaust3==1){
                txt_fan3.setText("ON");
                txt_fan3.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan3.setVisibility(View.VISIBLE);
                dash_off_fan3.setVisibility(View.GONE);
            } else {
                txt_fan3.setText("OFF");
                txt_fan3.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan3.setVisibility(View.GONE);
                dash_off_fan3.setVisibility(View.VISIBLE);
            }

            //Kipas 4
            if(exhaust4==1){
                txt_fan4.setText("ON");
                txt_fan4.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan4.setVisibility(View.VISIBLE);
                dash_off_fan4.setVisibility(View.GONE);
            } else {
                txt_fan4.setText("OFF");
                txt_fan4.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan4.setVisibility(View.GONE);
                dash_off_fan4.setVisibility(View.VISIBLE);
            }

            //Kipas 5
            if(exhaust5==1){
                txt_fan5.setText("ON");
                txt_fan5.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan5.setVisibility(View.VISIBLE);
                dash_off_fan5.setVisibility(View.GONE);
            } else {
                txt_fan5.setText("OFF");
                txt_fan5.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan5.setVisibility(View.GONE);
                dash_off_fan5.setVisibility(View.VISIBLE);
            }

            //Kipas 6
            if(exhaust6==1){
                txt_fan6.setText("ON");
                txt_fan6.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan6.setVisibility(View.VISIBLE);
                dash_off_fan6.setVisibility(View.GONE);
            } else {
                txt_fan6.setText("OFF");
                txt_fan6.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan6.setVisibility(View.GONE);
                dash_off_fan6.setVisibility(View.VISIBLE);
            }

            //Kipas 7
            if(exhaust7==1){
                txt_fan7.setText("ON");
                txt_fan7.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan7.setVisibility(View.VISIBLE);
                dash_off_fan7.setVisibility(View.GONE);
            } else {
                txt_fan7.setText("OFF");
                txt_fan7.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan7.setVisibility(View.GONE);
                dash_off_fan7.setVisibility(View.VISIBLE);
            }

            //Kipas 8
            if(exhaust8==1){
                txt_fan8.setText("ON");
                txt_fan8.setTextColor(Color.parseColor("#22C600"));
                dash_on_fan8.setVisibility(View.VISIBLE);
                dash_off_fan8.setVisibility(View.GONE);
            } else {
                txt_fan8.setText("OFF");
                txt_fan8.setTextColor(Color.parseColor("#C60000"));
                dash_on_fan8.setVisibility(View.GONE);
                dash_off_fan8.setVisibility(View.VISIBLE);
            }
            //txt_fan2.setText(""+statusList.get(i).getExhaust2());
            //Heater1
            if(heater1==1){
                txt_heater1.setText("ON");
                txt_heater1.setTextColor(Color.parseColor("#22C600"));
                dash_on_heater1.setVisibility(View.VISIBLE);
                dash_off_heater1.setVisibility(View.GONE);
            } else {
                txt_heater1.setText("OFF");
                txt_heater1.setTextColor(Color.parseColor("#C60000"));
                dash_on_heater1.setVisibility(View.GONE);
                dash_off_heater1.setVisibility(View.VISIBLE);
            }

            //Heater2
            if(heater2==1){
                txt_heater2.setText("ON");
                txt_heater2.setTextColor(Color.parseColor("#22C600"));
                dash_on_heater2.setVisibility(View.VISIBLE);
                dash_off_heater2.setVisibility(View.GONE);
            } else {
                txt_heater2.setText("OFF");
                txt_heater2.setTextColor(Color.parseColor("#C60000"));
                dash_on_heater2.setVisibility(View.GONE);
                dash_off_heater2.setVisibility(View.VISIBLE);
            }

            //Evaporator
            if(evaporator==1){
                txt_evaporator.setText("ON");
                txt_evaporator.setTextColor(Color.parseColor("#22C600"));
                dash_on_evaporator.setVisibility(View.VISIBLE);
                dash_off_evaporator.setVisibility(View.GONE);
            } else {
                txt_evaporator.setText("OFF");
                txt_evaporator.setTextColor(Color.parseColor("#C60000"));
                dash_on_evaporator.setVisibility(View.GONE);
                dash_off_evaporator.setVisibility(View.VISIBLE);
            }
        }
    }
}